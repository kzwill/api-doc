# dix对接

**配置参数**

```
#dix的部署url
uino.dix-url=http://10.100.33.78:1551/tarsier-dix
```

**示例代码**

```
JSONObject jsonObject = JSONUtil.parseObj(body);
String projectId = jsonObject.getStr("projectId");//项目id
Integer maxPort = jsonObject.getInt("maxPort");//最大端口号
Integer minPort = jsonObject.getInt("minPort");//最小端口号
String url = DixProvider.getProvider().getConsoleUrl(projectId, maxPort, minPort);
```

# 模型转换

**配置参数**

```
#模型转换工具的路径地址
uino.mode-convertor-url=convertor
```

**配置文件**

```
将convertor_config.toml配置文件放到resources下面
```

**示例代码**

```
String sourcePath = "C:\\Users\\fbx";//源模型文件夹路径
String targetPath = "C:\\Users\\gltf";//转换完成后文件夹路径
String convertType = "gltf";//要转换成什么格式
ConvertInfo convertInfo = ModelConvertProvider.getProvider().convertModel(sourcePath, targetPath, convertType);
```

**convertCode**

```
0:"转换成功"
111: "不支持的导出类型",
112: "加载转换配置失败",
113: "没有发现支持导入的文件类型",
114: "发现有多个支持导入的文件",
115: "导入文件失败，需查看转换日志排查",
116: "不支持的转换配置",
117: "面数超过上线",
118: "面数为0",
119: "导出写文件失败",
120: "创建导出文件夹失败",
121: "拷贝贴图文件失败",
122: "修复贴图路径失败",
123: "写bundle json失败",
124: "写index json失败",
125: "NotSupportOlderFormatFbx",
126: "NotSupportNewerFormatFbx",
127: "InputFolderNotFound",
128: "InputIsNotFolder",
129: "FailedToConvertFbxVersion",
130: "NotFoundBinFromGltfFile",
131: "InvalidFaceIndex",
132: "FailedToImportFbxWithFBXSDK",
133: "FailedToExportFbxWithFBXSDK",
```



# 模型信息

**示例代码**

```
String sourcePath = "C:\\Users\\gltf\\model.gltf";
ModelInfo modelInfo = ModelConvertProvider.getProvider().getModelInfo(sourcePath);
```

**返回参数**

```
faces：面数
vertices：点数
textures：纹理
solidMsg：长宽高
animations：动画
```

# 项目数据统计

**配置参数**

```
#ThingX的部署地址
uino.thingx-url=http://10.100.33.78/thing
```

**示例代码**

```
String token = "312912b0484e1547154f6962fc35d78a03e7518dfd34ffbc67379d429813a721875dcb51dffc277bbce9d65073";
ProjectData projectData = ThingxConvertProvider.getProvider().countProjectData(token);
```

**返回参数**

```
sceneCount：场景数量
modelCount：模型数量
resourceCount：资源数量
```
