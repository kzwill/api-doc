export { default as ImagePreview } from './src/Preview.vue';
export { createImgPreview } from './src/functional';
