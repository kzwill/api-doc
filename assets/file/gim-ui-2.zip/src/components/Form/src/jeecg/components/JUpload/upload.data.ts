export enum UploadTypeEnum {
  all = 'all',
  image = 'image',
  file = 'file',
}
