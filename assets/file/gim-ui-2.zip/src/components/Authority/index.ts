import { withInstall } from '/@/utils';
import authority from './src/Authority.vue';

export const Authority = withInstall(authority);
